<?php

function dd($value){
    echo "<pre>";
    var_dump($value);
    die;
}

const BASE_URL = "tự sửa đường dẫn vào đây";

?>