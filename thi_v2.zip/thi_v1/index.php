<?php
session_start();
require_once './vendor/autoload.php';
require_once './commons/helpers.php';
require_once './config/database.php';
require_once './config/routing.php';


?>